﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace _8.FluentAPI.Migrations
{
    /// <inheritdoc />
    public partial class AddStudentAddressFixDataOneToOne : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "StudentAddresses",
                keyColumn: "StudentAddressId",
                keyValue: 2,
                column: "AddressOfStudentId",
                value: 2);

            migrationBuilder.UpdateData(
                table: "StudentAddresses",
                keyColumn: "StudentAddressId",
                keyValue: 3,
                column: "AddressOfStudentId",
                value: 3);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "StudentAddresses",
                keyColumn: "StudentAddressId",
                keyValue: 2,
                column: "AddressOfStudentId",
                value: 1);

            migrationBuilder.UpdateData(
                table: "StudentAddresses",
                keyColumn: "StudentAddressId",
                keyValue: 3,
                column: "AddressOfStudentId",
                value: 2);
        }
    }
}
