﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace _8.FluentAPI.Migrations
{
    /// <inheritdoc />
    public partial class AddStudentAddressFixDataOneToOneWithoutDataAgain : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "StudentAddressId",
                table: "StudentAddresses",
                newName: "Id");

            migrationBuilder.InsertData(
                table: "StudentAddresses",
                columns: new[] { "Id", "Address", "AddressOfStudentId", "City", "Country", "State" },
                values: new object[,]
                {
                    { 1, "123 Main St", 1, "New York", "USA", "NY" },
                    { 2, "456 Elm St", 2, "Los Angeles", "USA", "CA" },
                    { 3, "789 Oak St", 3, "Chicago", "USA", "IL" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "StudentAddresses",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "StudentAddresses",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "StudentAddresses",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "StudentAddresses",
                newName: "StudentAddressId");
        }
    }
}
